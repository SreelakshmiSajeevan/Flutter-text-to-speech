package com.sree.flutter_text_to_speech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
